public class Main {

    public static void main(String[] args) {

        // Motoristas
        Motorista m1 = new Motorista(
                "Gabriel",
                "11111111111",
                2027
        );

        Motorista m2 = new Motorista(
                "Carlos",
                "22222222222",
                2020
        );

        // Veículos
        Veiculo v1 = new Veiculo(
                "ABC1234",
                "Caminhão",
                100
        );

        Veiculo v2 = new Veiculo(
                "XYZ9999",
                "Van",
                80
        );

        // Viagem inválida
        Viagem viagem1 = new Viagem(
                "São Paulo",
                200,
                m2,
                v1
        );

        viagem1.iniciarViagem();

        System.out.println();

        // Abastecer veículo
        v1.abastecer(50);

        // Viagem válida
        Viagem viagem2 = new Viagem(
                "Rio de Janeiro",
                300,
                m1,
                v1
        );

        viagem2.iniciarViagem();
        viagem2.gerarRelatorio();
    }
}
