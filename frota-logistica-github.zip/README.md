# Sistema de Gestão de Frota Logística

Projeto desenvolvido em Java utilizando conceitos de Programação Orientada a Objetos (POO).

## Funcionalidades
- Cadastro de motoristas
- Cadastro de veículos
- Controle de combustível
- Verificação de CNH
- Criação de viagens
- Relatório da viagem

## Estrutura
- Motorista.java
- Veiculo.java
- Viagem.java
- Main.java

## Como executar

Compile os arquivos:

```bash
javac *.java
```

Execute:

```bash
java Main
```
