public class Veiculo {

    private String placa;
    private String modelo;
    private float capacidadeTanque;
    private float combustivelAtual;

    public Veiculo(String placa, String modelo, float capacidadeTanque) {
        this.placa = placa;
        this.modelo = modelo;
        this.capacidadeTanque = capacidadeTanque;
        this.combustivelAtual = 0;
    }

    public String getPlaca() {
        return placa;
    }

    public String getModelo() {
        return modelo;
    }

    public float getCombustivelAtual() {
        return combustivelAtual;
    }

    public void setCombustivelAtual(float combustivelAtual) {
        if (combustivelAtual < 0) {
            System.out.println("Combustível não pode ser negativo!");
        } else {
            this.combustivelAtual = combustivelAtual;
        }
    }

    public void abastecer(float litros) {

        if (combustivelAtual + litros > capacidadeTanque) {
            System.out.println("Capacidade do tanque excedida!");
        } else {
            combustivelAtual += litros;
            System.out.println("Veículo abastecido!");
        }
    }

    public boolean viajar(float distancia) {

        float consumo = distancia / 10;

        if (combustivelAtual >= consumo) {
            combustivelAtual -= consumo;
            return true;
        } else {
            System.out.println("Combustível insuficiente!");
            return false;
        }
    }
}
