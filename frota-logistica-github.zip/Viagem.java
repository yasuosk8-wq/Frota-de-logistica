public class Viagem {

    private String destino;
    private float distanciaTotal;
    private Motorista motorista;
    private Veiculo veiculo;

    public Viagem(String destino, float distanciaTotal,
                   Motorista motorista, Veiculo veiculo) {

        this.destino = destino;
        this.distanciaTotal = distanciaTotal;
        this.motorista = motorista;
        this.veiculo = veiculo;
    }

    public void iniciarViagem() {

        if (motorista == null || veiculo == null) {
            System.out.println("Motorista ou veículo inválido!");
            return;
        }

        if (!motorista.cnhValida()) {
            System.out.println("CNH vencida! Viagem não permitida.");
            return;
        }

        boolean sucesso = veiculo.viajar(distanciaTotal);

        if (sucesso) {
            System.out.println("Viagem iniciada com sucesso!");
        }
    }

    public void gerarRelatorio() {

        System.out.println("===== RELATÓRIO =====");
        System.out.println("Destino: " + destino);
        System.out.println("Motorista: " + motorista.getNome());
        System.out.println("Veículo: " + veiculo.getModelo());
        System.out.println("Combustível restante: "
                + veiculo.getCombustivelAtual() + "L");
    }
}
