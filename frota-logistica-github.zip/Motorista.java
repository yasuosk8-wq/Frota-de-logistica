public class Motorista {

    private String nome;
    private String cpf;
    private int validadeCnh;

    public Motorista(String nome, String cpf, int validadeCnh) {
        setNome(nome);
        this.cpf = cpf;
        this.validadeCnh = validadeCnh;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            System.out.println("Nome inválido!");
        } else {
            this.nome = nome;
        }
    }

    public String getCpf() {
        return cpf;
    }

    public int getValidadeCnh() {
        return validadeCnh;
    }

    public void setValidadeCnh(int validadeCnh) {
        this.validadeCnh = validadeCnh;
    }

    public boolean cnhValida() {
        return validadeCnh >= 2024;
    }
}
